<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Labo 01 - oefening 3</title>
</head>
<body>
	<pre><?php
        // enter your PHP code here
		$firstName = 'Joran';
		$lastName = 'Anseau';
		echo 'hello world';
		echo '<br>';
		echo 'It\'s raining outside';
		echo '<br>';
		echo 'The value of $firstName is ' . $firstName . '. The value of $lastName is ' . $lastName;

?>
	</pre>
</body>
</html>