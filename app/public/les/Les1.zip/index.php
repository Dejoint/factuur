<?php
header("Location: http://localhost:8080/naam.php/"); 
exit;
?>